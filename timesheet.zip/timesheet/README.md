# TimeSheet
TimeSheet | Flask | Python
#### TODO: Para calcular se a carga horária do funcionario foi cumprida durante o mês olhar a carga horária mensal dele (ou a semanal)
